
import ATM.ATM;

public class Main {
    public static void main(String[] args) {
        ATM theATM = new ATM();
        theATM.run();
    }
}